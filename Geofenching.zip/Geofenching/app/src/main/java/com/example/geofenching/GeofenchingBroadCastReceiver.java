package com.example.geofenching;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.icu.text.UnicodeSetSpanner;
import android.widget.Toast;

public class GeofenchingBroadCastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving

   /*     // an Intent broadcast.
        throw new UnsupportedOperationException("Not yet implemented");*/
        Toast.makeText(context,"geofenching found", Toast.LENGTH_LONG).show();
    }
}
