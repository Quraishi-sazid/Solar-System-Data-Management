package com.mygalaxy.api.productauthentication.model;


import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name = "tbl_data_product_info")
@EntityListeners(AuditingEntityListener.class)
public class ProductModel {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="product_id")
    private Long productId;
	
	@Column(name="serial_no")
    private String SerialNo;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "product_type_id" , referencedColumnName = "product_type_id")
    private ProductTypeModel productTypeModel;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "distributor_id" , referencedColumnName = "distributor_id")
    private DistributorModel distributorModel;
	
	@Column(name="is_authorised")
    private String isAuthorised;
	
}
