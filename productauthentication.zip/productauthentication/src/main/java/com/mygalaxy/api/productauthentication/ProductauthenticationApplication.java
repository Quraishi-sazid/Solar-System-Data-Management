package com.mygalaxy.api.productauthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductauthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductauthenticationApplication.class, args);
	}
	

}
