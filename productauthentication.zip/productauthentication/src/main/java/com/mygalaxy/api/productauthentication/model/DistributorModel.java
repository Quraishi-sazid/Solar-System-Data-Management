package com.mygalaxy.api.productauthentication.model;


import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@Entity
@Table(name = "tbl_data_distritributor_info")
@EntityListeners(AuditingEntityListener.class)

public class DistributorModel {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="distributor_id")
    private Short distributorId;
	
	@Column(name="distributor_name")
    private String distributorName;
	

	 @OneToMany(mappedBy = "distributorModel")
	 private List<ProductModel> productModelList;
	

}
