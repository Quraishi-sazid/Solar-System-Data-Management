package com.mygalaxy.api.productauthentication.model;


import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@Entity
@Table(name = "tbl_data_product_type")
@EntityListeners(AuditingEntityListener.class)

public class ProductTypeModel {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="product_type_id")
    private Short productTypeID;
	
	@Column(name="product_type_name")
    private String productTypeName;
	

	 @OneToMany(mappedBy = "productTypeModel")
	 private List<ProductModel> productModelList;
	

}
